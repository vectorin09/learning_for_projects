.\objects\portasm.o: ..\Source\portable\RVDS\ARM7_LPC21xx\portASM.s
.\objects\portasm.o: ..\Source\portable\RVDS\ARM7_LPC21xx\portmacro.inc
