/* Standard includes. */
#include <stdlib.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"

#define mainBUS_CLK_FULL	( ( unsigned char ) 0x01 )

#define mainCHECK_TASK_PRIORITY		( tskIDLE_PRIORITY + 3 )

static void vLEDTask(void* pvParameters)
{
	int i;
		PINSEL0 &=~(3 << 19);
		IODIR0 |= ( 1<< 10 );
		while(1)
		{
				IOSET0 |= ( 1<< 10 );
				for(i=0;i<5000000;i++){}
			  IOCLR0 |= ( 1<< 10 );
				for(i=0;i<5000000;i++){}	
		}

}

static void vLEDTask1(void* pvParameters)
{
	int i;
		PINSEL0 &=~(3 << 17);
		IODIR0 |= ( 1<< 9 );
		while(1)
		{
				IOSET0 |= ( 1<< 9 );
				for(i=0;i<5000000;i++){}
			  IOCLR0 |= ( 1<< 9 );
				for(i=0;i<5000000;i++){}	
		}

}
static void prvSetupHardware( void );

int main( void )
{

	prvSetupHardware();
	xTaskCreate( vLEDTask, "LED", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
  xTaskCreate( vLEDTask1, "LED1", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
	vTaskStartScheduler();
	for( ;; );
}

static void prvSetupHardware( void )
{
		VPBDIV = mainBUS_CLK_FULL;
}
